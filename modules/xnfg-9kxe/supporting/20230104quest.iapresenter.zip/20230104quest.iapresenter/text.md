# Making all research work visible
#### ResearchEquals.com

Hi everyone, for Liberate Science, I'm Chris Hartgerink.

Today I'll pitch you ResearchEquals - a community of researchers sharing their research process. 

// don't be a stranger on Slack, I'm happy to chat if we don't get the chance right now.
// 
---
## Paper research is...

Currently, research is a lot of different, unknown things that get joined up in a final report.

/assets/Old Way.svg
size: contain

These invisible research steps are the building blocks of your papers, yet that they exist or how they relate is hard to figure out. 

They often don't see the light of day, collect dust in your Dropbox or Google drive, and over time memory fades and jobs change.

During my own PhD research, I did a lot to improve my research practices that nobody saw. 

Dynamic documents, reproducible code, rejected conference abstracts. And much, much more.

Lots of that work remained invisible, and that led me to ask: Why?

Ultimately, publishing was the bottleneck. Research changed faster than publishing, and we are publishing words for things better expressed in its original format. Like data or code.

---

/assets/ResearchEquals.svg
size: contain

## Research Modules [^https://doi.org/10.3390/publications6020021] 

This leads to the concept of research modules.

A research module is a research step, that can be reused and built upon. It stands on its own, yet relates to previous work. 

Standing on the building blocks of giants, so to speak.

These research modules are shared as you go through your research process, allowing you to keep much better track of your own work and that of your peers.

Plus, it embeds the process driven nature of research into how we publish

---

/assets/Screenshot 2023-01-03 at 14.05.39.png.public.png
size: contain

so that we can focus on where things come from, instead of how good it sounds.

Additionally, it allows each step to be contributed by someone else, without losing track of who contributed what. 

We can start mapping the process with which research evolves, and make the reality of the work visible.


---
/assets/Screenshot 2023-01-03 at 14.23.45.png.public.png
size: contain

So, you might ask, what kinds of research modules are there?

Just like research, this keeps evolving. 

We currently have a preselected list ranging from blog posts to ethical review applications, from data to code, to presentations. 

But you can also publish open hardware files, recordings of study protocols, and study materials.

You publish the research steps you want, when you want.

---


/assets/Screenshot 2023-01-03 at 14.23.55.png.public.png
size: contain

As you go along your journey, you link up these steps to showcase the developing research paths.

That means you actually get to map your garden of forking paths, allowing you to end certain unfruitful efforts, without keeping them in a file drawer of unpublished work.

All this because you've published the process up til then.

---

/assets/Screenshot 2023-01-03 at 14.24.19.png.public.png
size: contain

We hold open access dear, so that's free. You can pay, if you want

---

/assets/Screenshot 2023-01-03 at 14.44.45.png.public.png
size: contain

More importantly, since we launched last February, we've seen a steady group of people flocking to the platform and a new community forming.

This community is asking how modular research publishing fits into how we do research now, and how it changes research.  

We are now in the process of cultivating the community of researchers sharing their research process, such that we can cultivate this practice into a more standard form of sharing your work.

---



/assets/Frame 246.svg
size: contain

/assets/Screenshot 2023-01-03 at 14.25.33.png
size: contain

/assets/Screenshot 2023-01-03 at 14.25.23.png
size: contain

## Evolving with the community

Together with the community we keep assessing and evolving what ResearchEquals is, can do and provides to make all your research work visible.

We already added ResearchEquals Collections, which allows you to start an overlay journal, curating research published anywhere with a DOI. 

We're starting a peer learning community, where ECRs like yourself can learn together and discover what it is to share your research process.

So come join our community of research sharers, join ResearchEquals 😊

---
# What can you do?

	- [x] Get to know about ResearchEquals
	- [ ] Give it a try at [ResearchEquals.com](https://researchequals.com)
	- [ ] Join [a future ResearchEquals Cohort](https://nut.sh/ell/forms/339732/lNoIU9)

You've already taken the first step! 

You can continue by going over to ResearchEquals.com and giving it a try, or if you'd like to join a future cohort, by letting us know you're interested!

Thank you and I look forward to talking with you today and tomorrow!